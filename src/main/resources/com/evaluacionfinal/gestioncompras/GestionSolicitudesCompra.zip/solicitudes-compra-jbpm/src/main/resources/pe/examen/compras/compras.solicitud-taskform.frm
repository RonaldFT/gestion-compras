{
  "id": "0e9eb299-9e30-4d46-9171-a2ebe00a3494",
  "name": "compras.solicitud-taskform.frm",
  "model": {
    "processId": "compras.solicitud",
    "name": "process",
    "properties": [],
    "formModelType": "org.kie.workbench.common.forms.jbpm.model.authoring.process.BusinessProcessFormModel",
    "processName": "Solicitud de compra"
  },
  "fields": [],
  "layoutTemplate": {
    "version": 2,
    "name": "compras.solicitud-taskform.frm",
    "style": "FLUID",
    "layoutProperties": {},
    "rows": []
  }
}
