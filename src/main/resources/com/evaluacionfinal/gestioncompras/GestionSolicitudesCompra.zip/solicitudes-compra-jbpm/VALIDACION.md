# Validación

- Motor: jBPM / Drools 7.74.1.Final.
- Java: OpenJDK 11.0.27.
- Maven: 3.9.9.
- Compilación: BUILD SUCCESS.
- Pruebas: 11 ejecutadas, 0 fallos, 0 errores.

## Casos ejecutados

- jsonInvalidoNoEsRechazo
- productoInexistente
- cantidadOmitida
- stockInsuficiente
- error503NoEsRechazo
- compraDirecta
- rechazoDelJefe
- aprobacionAdicional
- correoInvalidoSeCorrigeAntesDeConsultar
- cantidadInvalida
- limiteExacto500

## Alcance

Se cargaron y compilaron el BPMN y las reglas DRL con el motor real. Se recorrieron las tareas y se comprobaron resultados, ramas, total límite de 500 UM y separación entre rechazo de negocio y error técnico. Las llamadas HTTP se realizaron con el handler REST oficial hacia un servidor local con respuestas controladas. Las tareas humanas y Email se sustituyeron por handlers de prueba para completar y observar los recorridos. No se enviaron correos.

Los cuatro formularios JSON se incluyen para Business Central; no se verificó su renderizado en una instalación de Business Central. No se desplegó el proyecto en tu servidor, no se comprobó su proveedor de usuarios ni su persistencia, y no se probó SMTP con una cuenta Gmail. El acceso desde tu KIE Server al catálogo público DummyJSON también debe verificarse al desplegar. La consulta del listado público desde este entorno devolvió HTTP 403 y no se usó para afirmar una integración externa exitosa.

El diagrama PNG incluido es la vista conceptual acordada. El BPMN incorpora tareas auxiliares de preparación y gateways de unión requeridos por el motor.
