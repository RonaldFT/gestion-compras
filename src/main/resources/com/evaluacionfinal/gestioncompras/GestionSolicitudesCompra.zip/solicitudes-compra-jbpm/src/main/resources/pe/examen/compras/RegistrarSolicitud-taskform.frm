{
  "id": "2700f738-91d9-4832-96d6-ebf28e82e69a",
  "name": "RegistrarSolicitud-taskform.frm",
  "model": {
    "processId": "compras.solicitud",
    "name": "task",
    "properties": [
      {
        "name": "productoId",
        "typeInfo": {
          "type": "BASE",
          "className": "java.lang.Integer",
          "multiple": false
        },
        "metaData": {
          "entries": [
            {
              "name": "field-readOnly",
              "value": false
            }
          ]
        }
      },
      {
        "name": "cantidad",
        "typeInfo": {
          "type": "BASE",
          "className": "java.lang.Integer",
          "multiple": false
        },
        "metaData": {
          "entries": [
            {
              "name": "field-readOnly",
              "value": false
            }
          ]
        }
      },
      {
        "name": "email",
        "typeInfo": {
          "type": "BASE",
          "className": "java.lang.String",
          "multiple": false
        },
        "metaData": {
          "entries": [
            {
              "name": "field-readOnly",
              "value": false
            }
          ]
        }
      },
      {
        "name": "motivo",
        "typeInfo": {
          "type": "BASE",
          "className": "java.lang.String",
          "multiple": false
        },
        "metaData": {
          "entries": [
            {
              "name": "field-readOnly",
              "value": false
            }
          ]
        }
      }
    ],
    "formModelType": "org.kie.workbench.common.forms.jbpm.model.authoring.task.TaskFormModel",
    "taskName": "RegistrarSolicitud"
  },
  "fields": [
    {
      "id": "field_5594c81880ad4a9b94aa868f62a72669",
      "name": "productoId",
      "label": "ID del producto",
      "required": true,
      "readOnly": false,
      "validateOnChange": true,
      "binding": "productoId",
      "standaloneClassName": "java.lang.Integer",
      "code": "IntegerBox",
      "serializedFieldClassName": "org.kie.workbench.common.forms.fields.shared.fieldTypes.basic.integerBox.definition.IntegerBoxFieldDefinition",
      "maxLength": 200
    },
    {
      "id": "field_576609741aa64898bdb3dc80aa8f2ff4",
      "name": "cantidad",
      "label": "Cantidad solicitada",
      "required": true,
      "readOnly": false,
      "validateOnChange": true,
      "binding": "cantidad",
      "standaloneClassName": "java.lang.Integer",
      "code": "IntegerBox",
      "serializedFieldClassName": "org.kie.workbench.common.forms.fields.shared.fieldTypes.basic.integerBox.definition.IntegerBoxFieldDefinition",
      "maxLength": 200
    },
    {
      "id": "field_3695339e3cd54f68b8a51c481f2a96f9",
      "name": "email",
      "label": "Correo del solicitante",
      "required": true,
      "readOnly": false,
      "validateOnChange": true,
      "binding": "email",
      "standaloneClassName": "java.lang.String",
      "code": "TextBox",
      "serializedFieldClassName": "org.kie.workbench.common.forms.fields.shared.fieldTypes.basic.textBox.definition.TextBoxFieldDefinition",
      "maxLength": 200
    },
    {
      "id": "field_c87993a75a8d4874a24e58da14c6c4ae",
      "name": "motivo",
      "label": "Justificacion de la compra",
      "required": true,
      "readOnly": false,
      "validateOnChange": true,
      "binding": "motivo",
      "standaloneClassName": "java.lang.String",
      "code": "TextArea",
      "serializedFieldClassName": "org.kie.workbench.common.forms.fields.shared.fieldTypes.basic.textArea.definition.TextAreaFieldDefinition",
      "rows": 4
    }
  ],
  "layoutTemplate": {
    "version": 2,
    "name": "RegistrarSolicitud-taskform.frm",
    "style": "FLUID",
    "layoutProperties": {},
    "rows": [
      {
        "height": "12",
        "layoutColumns": [
          {
            "span": "12",
            "height": "12",
            "rows": [],
            "layoutComponents": [
              {
                "dragTypeName": "org.kie.workbench.common.forms.editor.client.editor.rendering.EditorFieldLayoutComponent",
                "properties": {
                  "field_id": "field_5594c81880ad4a9b94aa868f62a72669",
                  "form_id": "2700f738-91d9-4832-96d6-ebf28e82e69a"
                }
              }
            ]
          }
        ]
      },
      {
        "height": "12",
        "layoutColumns": [
          {
            "span": "12",
            "height": "12",
            "rows": [],
            "layoutComponents": [
              {
                "dragTypeName": "org.kie.workbench.common.forms.editor.client.editor.rendering.EditorFieldLayoutComponent",
                "properties": {
                  "field_id": "field_576609741aa64898bdb3dc80aa8f2ff4",
                  "form_id": "2700f738-91d9-4832-96d6-ebf28e82e69a"
                }
              }
            ]
          }
        ]
      },
      {
        "height": "12",
        "layoutColumns": [
          {
            "span": "12",
            "height": "12",
            "rows": [],
            "layoutComponents": [
              {
                "dragTypeName": "org.kie.workbench.common.forms.editor.client.editor.rendering.EditorFieldLayoutComponent",
                "properties": {
                  "field_id": "field_3695339e3cd54f68b8a51c481f2a96f9",
                  "form_id": "2700f738-91d9-4832-96d6-ebf28e82e69a"
                }
              }
            ]
          }
        ]
      },
      {
        "height": "12",
        "layoutColumns": [
          {
            "span": "12",
            "height": "12",
            "rows": [],
            "layoutComponents": [
              {
                "dragTypeName": "org.kie.workbench.common.forms.editor.client.editor.rendering.EditorFieldLayoutComponent",
                "properties": {
                  "field_id": "field_c87993a75a8d4874a24e58da14c6c4ae",
                  "form_id": "2700f738-91d9-4832-96d6-ebf28e82e69a"
                }
              }
            ]
          }
        ]
      }
    ]
  }
}
