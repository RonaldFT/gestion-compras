{
  "id": "c21df82a-ca00-402f-8d76-40b05a457b7e",
  "name": "RegistrarOrden-taskform.frm",
  "model": {
    "processId": "compras.solicitud",
    "name": "task",
    "properties": [
      {
        "name": "resumen",
        "typeInfo": {
          "type": "BASE",
          "className": "java.lang.String",
          "multiple": false
        },
        "metaData": {
          "entries": [
            {
              "name": "field-readOnly",
              "value": true
            }
          ]
        }
      },
      {
        "name": "numeroOrden",
        "typeInfo": {
          "type": "BASE",
          "className": "java.lang.String",
          "multiple": false
        },
        "metaData": {
          "entries": [
            {
              "name": "field-readOnly",
              "value": false
            }
          ]
        }
      }
    ],
    "formModelType": "org.kie.workbench.common.forms.jbpm.model.authoring.task.TaskFormModel",
    "taskName": "RegistrarOrden"
  },
  "fields": [
    {
      "id": "field_8b567eda0aac4e3ca773bb3958937f88",
      "name": "resumen",
      "label": "Detalle de la solicitud autorizada",
      "required": false,
      "readOnly": true,
      "validateOnChange": true,
      "binding": "resumen",
      "standaloneClassName": "java.lang.String",
      "code": "TextArea",
      "serializedFieldClassName": "org.kie.workbench.common.forms.fields.shared.fieldTypes.basic.textArea.definition.TextAreaFieldDefinition",
      "rows": 4
    },
    {
      "id": "field_d96ddd0bd1654881bf6da5ca5c667f69",
      "name": "numeroOrden",
      "label": "Numero de orden de compra",
      "required": true,
      "readOnly": false,
      "validateOnChange": true,
      "binding": "numeroOrden",
      "standaloneClassName": "java.lang.String",
      "code": "TextBox",
      "serializedFieldClassName": "org.kie.workbench.common.forms.fields.shared.fieldTypes.basic.textBox.definition.TextBoxFieldDefinition",
      "maxLength": 200
    }
  ],
  "layoutTemplate": {
    "version": 2,
    "name": "RegistrarOrden-taskform.frm",
    "style": "FLUID",
    "layoutProperties": {},
    "rows": [
      {
        "height": "12",
        "layoutColumns": [
          {
            "span": "12",
            "height": "12",
            "rows": [],
            "layoutComponents": [
              {
                "dragTypeName": "org.kie.workbench.common.forms.editor.client.editor.rendering.EditorFieldLayoutComponent",
                "properties": {
                  "field_id": "field_8b567eda0aac4e3ca773bb3958937f88",
                  "form_id": "c21df82a-ca00-402f-8d76-40b05a457b7e"
                }
              }
            ]
          }
        ]
      },
      {
        "height": "12",
        "layoutColumns": [
          {
            "span": "12",
            "height": "12",
            "rows": [],
            "layoutComponents": [
              {
                "dragTypeName": "org.kie.workbench.common.forms.editor.client.editor.rendering.EditorFieldLayoutComponent",
                "properties": {
                  "field_id": "field_d96ddd0bd1654881bf6da5ca5c667f69",
                  "form_id": "c21df82a-ca00-402f-8d76-40b05a457b7e"
                }
              }
            ]
          }
        ]
      }
    ]
  }
}
