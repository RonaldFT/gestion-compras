package pe.examen.compras;
import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import com.sun.net.httpserver.HttpServer;
import org.kie.api.KieBase;
import org.kie.api.runtime.KieSession;
import org.kie.api.io.ResourceType;
import org.kie.internal.utils.KieHelper;
import org.kie.api.runtime.process.*;
import org.jbpm.process.workitem.rest.RESTWorkItemHandler;

public class ProcesoCompraTest {
 private static HttpServer server;
 private static KieBase base;
 private KieSession session;
 private final Map<String, WorkItem> pending = new HashMap<>();
 private final List<WorkItem> emails = new ArrayList<>();
 private WorkflowProcessInstance process;
 @BeforeClass public static void prepare() throws Exception {
  server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0),0);
  server.createContext("/products", e -> {
   String path=e.getRequestURI().getPath(); int id=Integer.parseInt(path.substring(path.lastIndexOf('/')+1));
   int status=id==9999?404:id==5000?503:200;
   String body=id==5001?"invalid json":status!=200?"{\"message\":\"unavailable\"}":"{\"id\":"+id+",\"title\":\"Producto prueba\",\"price\":"+(id==2?600:id==3?250:100)+",\"stock\":20}";
   byte[] data=body.getBytes(StandardCharsets.UTF_8);e.getResponseHeaders().set("Content-Type","application/json");e.sendResponseHeaders(status,data.length);e.getResponseBody().write(data);e.close();
  });
  server.start(); System.setProperty("compras.catalogo.url","http://127.0.0.1:"+server.getAddress().getPort()+"/products");
  KieHelper helper=new KieHelper();
  helper.addResource(org.kie.internal.io.ResourceFactory.newClassPathResource("pe/examen/compras/solicitud-compra.bpmn2"),ResourceType.BPMN2);
  helper.addResource(org.kie.internal.io.ResourceFactory.newClassPathResource("pe/examen/compras/reglas-compras.drl"),ResourceType.DRL);
  assertFalse(helper.verify().getMessages().toString(), helper.verify().hasMessages(org.kie.api.builder.Message.Level.ERROR));
  base=helper.build();
 }
 @AfterClass public static void stop(){ if(server!=null) server.stop(0);System.clearProperty("compras.catalogo.url"); }
 @Before public void session(){
  session=base.newKieSession();
  session.getWorkItemManager().registerWorkItemHandler("Human Task",new WorkItemHandler(){
   public void executeWorkItem(WorkItem w,WorkItemManager m){pending.put((String)w.getParameter("TaskName"),w);}
   public void abortWorkItem(WorkItem w,WorkItemManager m){}
  });
  session.getWorkItemManager().registerWorkItemHandler("Rest",new RESTWorkItemHandler());
  session.getWorkItemManager().registerWorkItemHandler("Email",new WorkItemHandler(){
   public void executeWorkItem(WorkItem w,WorkItemManager m){emails.add(w);m.completeWorkItem(w.getId(),Collections.emptyMap());}
   public void abortWorkItem(WorkItem w,WorkItemManager m){}
  });
 }
 @After public void dispose(){if(session!=null)session.dispose();}
 private void complete(String task, Map<String,Object> result){WorkItem w=pending.remove(task);assertNotNull("Tarea pendiente: "+task,w);session.getWorkItemManager().completeWorkItem(w.getId(),result);session.fireAllRules();}
 private void request(int id,Integer amount){
  process=(WorkflowProcessInstance)session.startProcess("compras.solicitud");
  Map<String,Object> r=new HashMap<>();r.put("productoId",id);r.put("cantidad",amount);r.put("email","prueba@example.com");r.put("motivo","Compra para el area administrativa");complete("RegistrarSolicitud",r);
 }
 private SolicitudCompra data(){return (SolicitudCompra)process.getVariable("solicitud");}
 private void order(){complete("RegistrarOrden",Collections.singletonMap("numeroOrden","OC-2026-001"));}
 private void finished(String outcome){assertEquals(ProcessInstance.STATE_COMPLETED,process.getState());assertEquals(outcome,data().getResultado());assertEquals(1,emails.size());assertEquals("prueba@example.com",emails.get(0).getParameter("To"));assertTrue(((String)emails.get(0).getParameter("Body")).contains(outcome));assertTrue(pending.isEmpty());assertEquals(0,session.getFactCount());}
 @Test public void compraDirecta(){request(1,2);assertEquals("DIRECTA",data().getRuta());assertFalse(pending.containsKey("AprobarSolicitud"));order();finished("ORDEN_REGISTRADA");}
 @Test public void limiteExacto500(){request(3,2);assertEquals("DIRECTA",data().getRuta());order();finished("ORDEN_REGISTRADA");}
 @Test public void aprobacionAdicional(){request(2,1);assertEquals("APROBACION",data().getRuta());complete("AprobarSolicitud",Collections.singletonMap("aprobada",true));order();finished("ORDEN_REGISTRADA");}
 @Test public void rechazoDelJefe(){request(2,1);complete("AprobarSolicitud",Collections.singletonMap("aprobada",false));finished("RECHAZADA");assertTrue(data().getDetalle().contains("jefe"));}
 @Test public void cantidadInvalida(){request(1,0);finished("RECHAZADA");assertTrue(data().getDetalle().contains("Datos invalidos"));}
 @Test public void cantidadOmitida(){request(1,null);finished("RECHAZADA");}
 @Test public void stockInsuficiente(){request(1,21);finished("RECHAZADA");assertTrue(data().getDetalle().contains("stock"));}
 @Test public void productoInexistente(){request(9999,1);finished("RECHAZADA");assertTrue(data().getDetalle().contains("no existe"));}
 @Test public void error503NoEsRechazo(){try{request(5000,1);fail("Debe fallar por HTTP 503");}catch(RuntimeException expected){assertTrue(emails.isEmpty());assertNotEquals(ProcessInstance.STATE_COMPLETED,process.getState());}}
 @Test public void jsonInvalidoNoEsRechazo(){try{request(5001,1);fail("Debe fallar por JSON invalido");}catch(RuntimeException expected){assertTrue(emails.isEmpty());assertNotEquals(ProcessInstance.STATE_COMPLETED,process.getState());}}
 @Test public void correoInvalidoSeCorrigeAntesDeConsultar(){try{ProcesoCompra.crear(1,1,"incorrecto","motivo");fail("Correo invalido");}catch(IllegalArgumentException expected){assertTrue(emails.isEmpty());}}
}
