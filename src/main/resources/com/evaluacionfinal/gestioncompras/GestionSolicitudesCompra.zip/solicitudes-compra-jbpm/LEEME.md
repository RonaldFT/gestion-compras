# Solicitudes de compra — jBPM 7.74

Proyecto de examen basado en el diagrama acordado. Compilado con **jBPM/Drools 7.74.1.Final y Java 11**. ID del proceso: `compras.solicitud`.

## Contenido

- `src/main/resources/pe/examen/compras/solicitud-compra.bpmn2`: BPMN ejecutable, carriles, coordenadas y conexiones.
- `src/main/resources/pe/examen/compras/reglas-compras.drl`: cinco reglas Drools del grupo `evaluar-compra`.
- Cuatro formularios `.frm`: inicio, registro, aprobación y orden.
- `SolicitudCompra.java`: objeto de datos serializable.
- `ProcesoCompra.java`: preparación de datos, lectura del JSON y construcción del correo.
- `GmailHandler.java`: envío con el handler Email de jBPM, configurado desde el entorno.
- `META-INF/kie-deployment-descriptor.xml`: registro de los handlers Rest y Email.
- `src/test/`: pruebas del proceso con el motor jBPM y peticiones HTTP a un catálogo local de pruebas.
- `compilado/`: KJAR compilado y POM correspondiente.
- `VALIDACION.md`: alcance y resultados de la verificación.

## Qué representa el proceso

1. El solicitante registra ID del producto, cantidad, correo y justificación.
2. La tarea **Rest** hace `GET https://dummyjson.com/products/{id}`.
3. Se leen `id`, `title`, `price` y `stock` de la respuesta JSON.
4. Drools rechaza datos inválidos, producto inexistente o stock insuficiente. Si la solicitud es válida, determina compra directa hasta 500 UM o aprobación adicional por encima de 500 UM.
5. El jefe aprueba o rechaza las compras de mayor importe.
6. Compras registra una referencia de orden, por ejemplo `OC-2026-001`.
7. Gmail comunica el resultado al correo ingresado.

**UM significa unidad monetaria del ejercicio.** El valor `price` no se convierte ni se etiqueta como soles. El umbral de 500 UM es una regla propuesta para este caso.

El total es precio por cantidad, redondeado a dos decimales. No se aplican impuestos, descuentos ni gastos de envío. Solo se utilizan los campos del catálogo necesarios para este alcance.

Registrar una orden conserva su referencia y el resultado en las variables del proceso de jBPM. **No realiza una compra real, no crea una orden en un ERP y no descuenta inventario en DummyJSON.** El catálogo externo contiene datos de demostración.

## Importar el proyecto editable en Business Central

El ZIP contiene un proyecto Maven. No se debe asumir que Business Central permite importar un proyecto completo subiendo este ZIP como un asset.

1. Extraer la carpeta `solicitudes-compra-jbpm`.
2. Colocar su contenido en un repositorio Git accesible desde el servidor de Business Central. `pom.xml` debe estar en la raíz del repositorio.
3. En Business Central, entrar a **Design → Projects**, seleccionar el espacio y utilizar **Import Project** con la URL del repositorio.
4. Abrir el proyecto e identificar el proceso **Solicitud de compra** y las reglas **reglas-compras**.
5. Comprobar que aparecen los formularios `RegistrarSolicitud-taskform`, `AprobarSolicitud-taskform`, `RegistrarOrden-taskform` y `compras.solicitud-taskform`.
6. Configurar los grupos y Gmail descritos abajo.
7. Usar **Build & Deploy** y después iniciar el proceso desde **Manage → Process Definitions**.

Si ya tienes un proyecto creado en Business Central, puedes incorporar los recursos y las tres clases Java con sus rutas y agregar las dependencias y los handlers del proyecto entregado. **Subir únicamente el BPMN permite ver el flujo, pero no aporta las reglas, clases, formularios ni dependencias necesarias para ejecutarlo.**

El KJAR en `compilado` sirve para un despliegue mediante repositorio Maven/KIE Server. Para editar el diagrama y los formularios en Business Central, importar el código fuente completo es la opción indicada. El despliegue requiere que las dependencias Maven del POM se puedan resolver; el JAR no contiene todas las dependencias dentro de sí.

## Usuarios y grupos

Configurar estos grupos en el proveedor de usuarios que utilice tu instalación:

| Usuario de ejemplo | Grupo requerido | Tarea |
|---|---|---|
| solicitante1 | `solicitantes` | RegistrarSolicitud |
| jefe1 | `jefes` | AprobarSolicitud |
| comprador1 | `compras` | RegistrarOrden |

Los nombres de los usuarios son ejemplos; la asignación del BPMN utiliza los grupos. Estos usuarios necesitan además los permisos habituales de acceso a Business Central de tu instalación. Los carriles documentan responsabilidades; **la asignación efectiva la hace `GroupId` en cada tarea humana**.

Al iniciar, el proceso crea la tarea de registro. Entrar a **Track → Task Inbox**, reclamar la tarea, iniciarla si corresponde y completarla. Cambiar al usuario del grupo que corresponda en cada etapa.

El campo `resumen` es de solo lectura en aprobación y registro de orden. En la aprobación, marcar la casilla significa aprobar; dejarla desmarcada significa rechazar.

## Configurar Gmail en el KIE Server

El handler obtiene estas variables del **proceso que ejecuta el KIE Server**:

- `GMAIL_USER`: cuenta remitente completa.
- `GMAIL_APP_PASSWORD`: contraseña de aplicación autorizada para esa cuenta.

En PowerShell, antes de iniciar el servidor desde esa misma consola:

```powershell
$env:GMAIL_USER = "tu-cuenta@gmail.com"
$env:GMAIL_APP_PASSWORD = "tu-contraseña-de-aplicacion"
```

En Linux, antes de iniciarlo desde esa misma consola:

```bash
export GMAIL_USER='tu-cuenta@gmail.com'
export GMAIL_APP_PASSWORD='tu-contraseña-de-aplicacion'
```

Después iniciar el servidor con el comando que ya utilizas. Si se ejecuta como servicio, contenedor o mediante otra consola, configurar las variables allí y reiniciar ese proceso. Un archivo `.env` por sí solo no es leído automáticamente por este proyecto.

La conexión está configurada para `smtp.gmail.com`, puerto `587`, STARTTLS. El correo se envía con el handler Email de jBPM. Las credenciales no se guardan en el BPMN ni se solicitan en formularios.

La contraseña de aplicación requiere verificación en dos pasos y que la cuenta permita esta función. Algunas cuentas institucionales o con políticas especiales no la ofrecen. Configuración oficial: https://support.google.com/accounts/answer/185833?hl=es

Sin las variables configuradas, la tarea Email genera un error explícito. No simula un envío exitoso ni finaliza el proceso como si el correo hubiera salido. Un fallo SMTP también genera error; revisar y resolver la causa antes de reintentar según las herramientas de tu instalación. No se configuró un circuito automático de reintentos.

## Escenarios para la exposición

Antes de la presentación, consultar el catálogo y elegir productos que mantengan el precio y stock necesarios. No depender de cantidades o precios antiguos de una captura.

| Escenario | Datos | Acción posterior | Resultado |
|---|---|---|---|
| Compra directa | Producto existente; cantidad positiva dentro del stock; total ≤ 500 UM | Compras ingresa un número de orden | ORDEN_REGISTRADA y correo |
| Aprobación adicional | Producto existente; stock suficiente; total > 500 UM | Jefe marca aprobar; Compras registra orden | ORDEN_REGISTRADA y correo |
| Rechazo del jefe | Solicitud válida de más de 500 UM | Jefe deja aprobar desmarcado | RECHAZADA y correo |
| Datos inválidos | Producto existente; cantidad 0; correo válido; justificación completa | Sin aprobación ni orden | RECHAZADA y correo con motivo |
| Stock insuficiente (adicional) | Cantidad mayor al stock publicado | Sin aprobación ni orden | RECHAZADA y correo con motivo |

El correo del solicitante debe ser válido para poder notificarlo. Una dirección mal formada se debe corregir antes de avanzar; no se intenta enviar un rechazo a una dirección inválida.

Un HTTP 404 se interpreta como producto inexistente. HTTP 5xx, errores de conexión o JSON incompatible se tratan como errores técnicos, **no como rechazos del negocio**. El proceso no debe considerarse terminado cuando ocurre uno de esos errores.

Para demostrar los recorridos de negocio, usar un correo real propio y capturar: la instancia, las tareas completadas por rol, las variables de resultado y el correo recibido. Estas evidencias se deben obtener en tu entorno.

## Compilar y ejecutar las pruebas

Con JDK 11 y Maven 3 instalados, desde la raíz del proyecto:

```bash
mvn clean package
```

El resultado se genera en `target/solicitudes-compra-1.0.0.jar`. Maven requiere acceso a Central y al repositorio público JBoss indicados en el POM.

Las pruebas ejecutan BPMN y DRL con jBPM real, usan el handler REST real contra un servidor HTTP local y simulan la interacción humana y la salida de correo. **No envían mensajes reales.** La comprobación de la interfaz de Business Central, autenticación por grupos, persistencia del servidor y Gmail real se realiza después del despliegue en tu instalación.

## Referencias

- jBPM 7.74.1: https://docs.jbpm.org/7.74.1.Final/jbpm-docs/html_single/
- Tareas de servicio 7.74.1: https://docs.jbpm.org/7.74.1.Final/service-repository/
- Catálogo: https://dummyjson.com/docs/products
