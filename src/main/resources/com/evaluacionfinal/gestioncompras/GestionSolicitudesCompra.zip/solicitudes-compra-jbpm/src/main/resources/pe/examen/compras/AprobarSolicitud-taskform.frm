{
  "id": "666f151a-a7c6-4d68-a67c-af098b0b5bc3",
  "name": "AprobarSolicitud-taskform.frm",
  "model": {
    "processId": "compras.solicitud",
    "name": "task",
    "properties": [
      {
        "name": "resumen",
        "typeInfo": {
          "type": "BASE",
          "className": "java.lang.String",
          "multiple": false
        },
        "metaData": {
          "entries": [
            {
              "name": "field-readOnly",
              "value": true
            }
          ]
        }
      },
      {
        "name": "aprobada",
        "typeInfo": {
          "type": "BASE",
          "className": "java.lang.Boolean",
          "multiple": false
        },
        "metaData": {
          "entries": [
            {
              "name": "field-readOnly",
              "value": false
            }
          ]
        }
      }
    ],
    "formModelType": "org.kie.workbench.common.forms.jbpm.model.authoring.task.TaskFormModel",
    "taskName": "AprobarSolicitud"
  },
  "fields": [
    {
      "id": "field_b356f0c0fde94b5aa578c109a6e0f65c",
      "name": "resumen",
      "label": "Detalle de la solicitud",
      "required": false,
      "readOnly": true,
      "validateOnChange": true,
      "binding": "resumen",
      "standaloneClassName": "java.lang.String",
      "code": "TextArea",
      "serializedFieldClassName": "org.kie.workbench.common.forms.fields.shared.fieldTypes.basic.textArea.definition.TextAreaFieldDefinition",
      "rows": 4
    },
    {
      "id": "field_43b1934771b6464fa16639efb2087866",
      "name": "aprobada",
      "label": "Aprobar solicitud (desmarcada = rechazar)",
      "required": false,
      "readOnly": false,
      "validateOnChange": true,
      "binding": "aprobada",
      "standaloneClassName": "java.lang.Boolean",
      "code": "CheckBox",
      "serializedFieldClassName": "org.kie.workbench.common.forms.fields.shared.fieldTypes.basic.checkBox.definition.CheckBoxFieldDefinition",
      "defaultValue": false
    }
  ],
  "layoutTemplate": {
    "version": 2,
    "name": "AprobarSolicitud-taskform.frm",
    "style": "FLUID",
    "layoutProperties": {},
    "rows": [
      {
        "height": "12",
        "layoutColumns": [
          {
            "span": "12",
            "height": "12",
            "rows": [],
            "layoutComponents": [
              {
                "dragTypeName": "org.kie.workbench.common.forms.editor.client.editor.rendering.EditorFieldLayoutComponent",
                "properties": {
                  "field_id": "field_b356f0c0fde94b5aa578c109a6e0f65c",
                  "form_id": "666f151a-a7c6-4d68-a67c-af098b0b5bc3"
                }
              }
            ]
          }
        ]
      },
      {
        "height": "12",
        "layoutColumns": [
          {
            "span": "12",
            "height": "12",
            "rows": [],
            "layoutComponents": [
              {
                "dragTypeName": "org.kie.workbench.common.forms.editor.client.editor.rendering.EditorFieldLayoutComponent",
                "properties": {
                  "field_id": "field_43b1934771b6464fa16639efb2087866",
                  "form_id": "666f151a-a7c6-4d68-a67c-af098b0b5bc3"
                }
              }
            ]
          }
        ]
      }
    ]
  }
}
