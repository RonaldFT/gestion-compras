package pe.examen.compras;

public class SolicitudCompra implements java.io.Serializable {
 private static final long serialVersionUID = 1L;
 private Integer productoId;
 private Integer cantidad;
 private String email;
 private String motivo;
 private String producto;
 private java.math.BigDecimal precio;
 private Integer stock;
 private java.math.BigDecimal total;
 private boolean encontrado;
 private String ruta = "PENDIENTE";
 private String resultado;
 private String detalle;
 public Integer getProductoId() { return productoId; }
 public void setProductoId(Integer value) { productoId = value; }
 public Integer getCantidad() { return cantidad; }
 public void setCantidad(Integer value) { cantidad = value; }
 public String getEmail() { return email; }
 public void setEmail(String value) { email = value; }
 public String getMotivo() { return motivo; }
 public void setMotivo(String value) { motivo = value; }
 public String getProducto() { return producto; }
 public void setProducto(String value) { producto = value; }
 public java.math.BigDecimal getPrecio() { return precio; }
 public void setPrecio(java.math.BigDecimal value) { precio = value; }
 public Integer getStock() { return stock; }
 public void setStock(Integer value) { stock = value; }
 public java.math.BigDecimal getTotal() { return total; }
 public void setTotal(java.math.BigDecimal value) { total = value; }
 public boolean isEncontrado() { return encontrado; }
 public void setEncontrado(boolean value) { encontrado = value; }
 public String getRuta() { return ruta; }
 public void setRuta(String value) { ruta = value; }
 public String getResultado() { return resultado; }
 public void setResultado(String value) { resultado = value; }
 public String getDetalle() { return detalle; }
 public void setDetalle(String value) { detalle = value; }
}
