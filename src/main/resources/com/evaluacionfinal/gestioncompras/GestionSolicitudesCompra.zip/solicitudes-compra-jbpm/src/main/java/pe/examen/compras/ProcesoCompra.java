package pe.examen.compras;
import java.math.BigDecimal;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public final class ProcesoCompra {
 private ProcesoCompra() {}
 public static SolicitudCompra crear(Integer productoId, Integer cantidad, String email, String motivo) {
  if(!emailValido(email)) throw new IllegalArgumentException("Ingrese un correo valido antes de continuar");
  SolicitudCompra s = new SolicitudCompra(); s.setProductoId(productoId); s.setCantidad(cantidad); s.setEmail(email); s.setMotivo(motivo); return s;
 }
 public static String url(Integer productoId) {
  String base = System.getProperty("compras.catalogo.url", "https://dummyjson.com/products");
  return base.replaceAll("/+$", "") + "/" + (productoId == null ? 0 : productoId);
 }
 public static void leerProducto(SolicitudCompra s, Integer status, String json) {
  if (Integer.valueOf(404).equals(status)) { s.setEncontrado(false); return; }
  if (status == null || status < 200 || status >= 300) throw new IllegalStateException("Error tecnico del catalogo. HTTP " + status + ". Corregir/reintentar la tarea; no es un rechazo de compra.");
  try {
   JsonNode n = new ObjectMapper().readTree(json);
   if(n == null || !n.path("id").isIntegralNumber() || s.getProductoId() == null || n.get("id").asInt() != s.getProductoId() || !n.path("title").isTextual() || !n.path("price").isNumber() || !n.path("stock").isIntegralNumber()) throw new IllegalArgumentException("Respuesta sin id, title, price o stock validos");
   BigDecimal price = n.get("price").decimalValue(); int stock = n.get("stock").asInt();
   if(price.signum() < 0 || stock < 0) throw new IllegalArgumentException("Precio o stock negativo");
   s.setEncontrado(true); s.setProducto(n.get("title").asText()); s.setPrecio(price); s.setStock(stock);
   if(s.getCantidad() != null) s.setTotal(price.multiply(BigDecimal.valueOf(s.getCantidad())).setScale(2, java.math.RoundingMode.HALF_UP));
  } catch(Exception e) { throw new IllegalStateException("Respuesta invalida del catalogo", e); }
 }
 public static String resumen(SolicitudCompra s) {
  return "Producto: " + s.getProducto() + " | Cantidad: " + s.getCantidad() + " | Total: " + s.getTotal() + " UM | Motivo: " + s.getMotivo();
 }
 public static boolean emailValido(String email) { return email != null && email.matches("^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"); }
 public static void decision(SolicitudCompra s, Boolean aprobada) {
  if(aprobada == null) throw new IllegalArgumentException("El jefe debe indicar aprobada=true o false");
  if(!aprobada) { s.setResultado("RECHAZADA"); s.setDetalle("Solicitud rechazada por el jefe."); }
 }
 public static void registrarOrden(SolicitudCompra s, String orden) {
  if(orden == null || orden.trim().isEmpty()) throw new IllegalArgumentException("Debe ingresar el numero de orden");
  s.setResultado("ORDEN_REGISTRADA"); s.setDetalle("Orden registrada: " + orden.trim());
 }
 private static String html(String value) { return value == null ? "" : value.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;"); }
 public static String correo(SolicitudCompra s) { return "<h2>Resultado de la solicitud de compra</h2><p>Estado: " + html(s.getResultado()) + "</p><p>" + html(s.getDetalle()) + "</p><p>" + html(resumen(s)) + "</p>"; }
}
