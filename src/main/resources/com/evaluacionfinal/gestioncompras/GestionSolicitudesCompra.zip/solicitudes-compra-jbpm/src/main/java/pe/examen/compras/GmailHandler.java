package pe.examen.compras;
import org.jbpm.process.workitem.email.EmailWorkItemHandler;
import org.kie.api.runtime.process.WorkItem;
import org.kie.api.runtime.process.WorkItemManager;
/** Credenciales solo del entorno del KIE Server; nunca del BPMN o formulario. */
public class GmailHandler extends EmailWorkItemHandler {
 @Override public void executeWorkItem(WorkItem item, WorkItemManager manager) {
  String user = System.getenv("GMAIL_USER"), password = System.getenv("GMAIL_APP_PASSWORD");
  if(user == null || user.trim().isEmpty() || password == null || password.trim().isEmpty()) throw new IllegalStateException("Configure GMAIL_USER y GMAIL_APP_PASSWORD en el proceso del KIE Server y reinicielo.");
  setConnection("smtp.gmail.com", "587", user, password.replace(" ", ""), "true");
  super.executeWorkItem(item, manager);
 }
}
